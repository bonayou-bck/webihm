<div class="text-end">
  <button type="button" class="btn btn-dark btn-label waves-effect waves-light mb-3">
    <i class="ri-file-list-2-line label-icon align-middle fs-16 me-2"></i> Save to Draft
  </button>
  <button type="button" class="btn btn-success btn-label waves-effect waves-light mb-3">
    <i class="ri-send-plane-line label-icon align-middle fs-16 me-2"></i> Publish
  </button>
  {{-- <button type="button" class="btn btn-primary btn-label waves-effect waves-light mb-3">
    <i class="ri-file-edit-line label-icon align-middle fs-16 me-2"></i> Send for Review
  </button> --}}
  <button type="button" class="btn btn-danger btn-label waves-effect waves-light mb-3">
    <i class="ri-close-line label-icon align-middle fs-16 me-2"></i> Reject
  </button>
</div>